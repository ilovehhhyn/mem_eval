"""
Test suite for the memory evaluation framework.
Demonstrates how to use the framework and implement tests.
"""

import pytest
from datetime import datetime
from ai_memory_eval.interfaces import BaseMemorySystem, MemoryEntry
from ai_memory_eval.evaluator import MemoryEvaluator
from ai_memory_eval.adapters.simple_memory import SimpleMemorySystem


def create_test_suite():
    """Create a standard test suite for memory system evaluation."""
    return {
        'retrieval_queries': [
            "What is the capital of France?",
            "How does photosynthesis work?",
            "Who invented the telephone?",
        ],
        'accuracy_tests': [
            {
                'query': "capital France",
                'expected': ["Paris is the capital of France"]
            },
            {
                'query': "photosynthesis process",
                'expected': ["Photosynthesis is the process by which plants convert sunlight into energy"]
            }
        ],
        'consistency_tests': [
            {
                'type': 'add',
                'content': "The Earth revolves around the Sun"
            },
            {
                'type': 'add',
                'content': "Water boils at 100 degrees Celsius"
            },
            {
                'type': 'update',
                'memory_id': "1",  # This will be replaced with actual ID
                'content': "Water boils at 100 degrees Celsius at sea level"
            }
        ]
    }


def test_simple_memory_system():
    """Test the SimpleMemorySystem implementation."""
    memory_system = SimpleMemorySystem()
    evaluator = MemoryEvaluator(memory_system)
    
    # Add some test memories
    memory_system.add_memory("Paris is the capital of France")
    memory_system.add_memory("Photosynthesis is the process by which plants convert sunlight into energy")
    
    # Run evaluation
    test_suite = create_test_suite()
    metrics = evaluator.run_evaluation(test_suite)
    
    # Basic assertions
    assert metrics.retrieval_accuracy >= 0.0
    assert metrics.retrieval_accuracy <= 1.0
    assert metrics.retrieval_latency >= 0.0
    assert metrics.consistency_score >= 0.0


def test_memory_operations():
    """Test basic memory operations."""
    memory_system = SimpleMemorySystem()
    
    # Test adding memory
    memory_id = memory_system.add_memory("Test memory content")
    assert memory_id is not None
    
    # Test retrieval
    memories = memory_system.retrieve_memories("Test memory")
    assert len(memories) > 0
    assert memories[0].content == "Test memory content"
    
    # Test updating memory
    updated = memory_system.update_memory(memory_id, "Updated content")
    assert updated is True
    
    # Test deletion
    deleted = memory_system.delete_memory(memory_id)
    assert deleted is True
    
    # Verify deletion
    memories = memory_system.retrieve_memories("Updated content")
    assert len(memories) == 0


def test_evaluator_metrics():
    """Test that evaluator metrics are calculated correctly."""
    memory_system = SimpleMemorySystem()
    evaluator = MemoryEvaluator(memory_system)
    
    # Add test data
    memory_system.add_memory("Test memory 1")
    memory_system.add_memory("Test memory 2")
    
    # Test retrieval latency
    latency = evaluator.measure_retrieval_latency(["Test"])
    assert latency > 0
    
    # Test accuracy
    accuracy = evaluator.evaluate_retrieval_accuracy([
        {
            'query': "Test memory",
            'expected': ["Test memory 1"]
        }
    ])
    assert 0 <= accuracy <= 1
    
    # Test consistency
    consistency = evaluator.evaluate_consistency([
        {'type': 'add', 'content': "New memory"},
        {'type': 'delete', 'memory_id': "non-existent-id"}
    ])
    assert 0 <= consistency <= 1
