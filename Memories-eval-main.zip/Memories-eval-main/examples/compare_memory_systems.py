"""
Example script demonstrating how to compare different memory systems
using the evaluation framework and visualization tools.
"""

import sys
import os
from datetime import datetime, timedelta
import random
from typing import List, Dict, Any

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai_memory_eval.evaluator import MemoryEvaluator
from ai_memory_eval.visualization import MemoryVisualizer
from ai_memory_eval.adapters.simple_memory import SimpleMemorySystem
from ai_memory_eval.adapters.mem0_adapter import Mem0System
from ai_memory_eval.adapters.m3_adapter import M3AgentMemory


def generate_test_data(num_entries: int = 100) -> List[Dict[str, Any]]:
    """
    Generate test data for memory system evaluation.
    
    Args:
        num_entries: Number of test entries to generate
        
    Returns:
        List[Dict]: List of test data entries
    """
    topics = [
        "science", "history", "technology", "art", 
        "literature", "mathematics", "geography"
    ]
    
    test_data = []
    for i in range(num_entries):
        topic = random.choice(topics)
        test_data.append({
            'content': f"Test memory {i} about {topic}",
            'metadata': {'topic': topic, 'importance': random.random()}
        })
    
    return test_data


def run_comparison(output_dir: str = 'comparison_results'):
    """
    Run a comparison between different memory systems.
    
    Args:
        output_dir: Directory to save visualization results
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize memory systems
    systems = {
        'SimpleMemory': SimpleMemorySystem(),
        'Mem0': Mem0System(),
        'M3Agent': M3AgentMemory()
    }
    
    # Initialize evaluator and visualizer
    visualizer = MemoryVisualizer()
    
    # Generate test data
    test_data = generate_test_data(100)
    
    # Collect metrics for each system
    metrics_dict = {}
    latencies_dict = {}
    accuracy_data = {}
    memory_data = {}
    
    for system_name, system in systems.items():
        evaluator = MemoryEvaluator(system)
        
        # Track metrics over time
        accuracies = []
        latencies = []
        memory_usage = []
        base_time = datetime.now()
        
        # Add memories and collect metrics
        for i, entry in enumerate(test_data):
            # Add memory
            system.add_memory(entry['content'], entry['metadata'])
            
            # Measure metrics every 10 entries
            if (i + 1) % 10 == 0:
                # Create test suite
                test_suite = {
                    'retrieval_queries': [
                        "science experiment",
                        "historical event",
                        "technological innovation"
                    ],
                    'accuracy_tests': [
                        {
                            'query': "science",
                            'expected': [m['content'] for m in test_data[:i+1] 
                                       if 'science' in m['content'].lower()]
                        }
                    ],
                    'consistency_tests': [
                        {'type': 'add', 'content': "New test memory"},
                        {'type': 'update', 'memory_id': "1", 'content': "Updated content"}
                    ]
                }
                
                # Run evaluation
                metrics = evaluator.run_evaluation(test_suite)
                
                # Collect data
                accuracies.append((base_time + timedelta(minutes=i), 
                                 metrics.retrieval_accuracy))
                latencies.extend([metrics.retrieval_latency])
                memory_usage.append((i + 1, metrics.memory_utilization / 1e6))  # Convert to MB
        
        # Store results
        metrics_dict[system_name] = metrics
        latencies_dict[system_name] = latencies
        accuracy_data[system_name] = accuracies
        memory_data[system_name] = memory_usage
    
    # Generate visualizations
    visualizer.plot_metrics_comparison(
        metrics_dict,
        os.path.join(output_dir, 'metrics_comparison.png')
    )
    
    visualizer.plot_latency_distribution(
        latencies_dict,
        os.path.join(output_dir, 'latency_distribution.png')
    )
    
    visualizer.plot_accuracy_over_time(
        accuracy_data,
        os.path.join(output_dir, 'accuracy_over_time.png')
    )
    
    visualizer.plot_memory_growth(
        memory_data,
        os.path.join(output_dir, 'memory_growth.png')
    )


if __name__ == "__main__":
    run_comparison()
